

<?php $__env->startSection('content'); ?>
<div class="container">
    <div class="row justify-content-center">
        <div class="col-md-8">
            <div class="card">
                <div class="card-header"><?php echo e(__('Update Post')); ?></div>

                <div class="card-body">
                    <?php if(session('status')): ?>
                        <div class="alert alert-success" role="alert">
                            <?php echo e(session('status')); ?>

                        </div>
                    <?php endif; ?>

                    

                    <?php if(Auth::user()->role_id == 1): ?>

                    <div class="p-2" style="text-align:right">

                        <a href="<?php echo e(route('home')); ?>" class="btn btn-primary "> View Post </a>
                       <!--  <button class="btn btn-primary "  type="button" data-toggle="modal" data-target="#myModal">Add Post</button> -->
                    </div>

                    <?php endif; ?>

                    <?php if($errors->any()): ?>
                        <div class="alert alert-danger">
                            <strong>Error!</strong> 
                            <ul>
                                <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <li></li>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </ul>
                        </div>
                    <?php endif; ?>

                   <form action="<?php echo e(route('post.update')); ?>" method="post">
                    <?php echo csrf_field(); ?>
                  <div class="form-group">
                    <label for="email">Title:</label>
                        <input type="text" name="title" class="form-control" id="title" value="<?php echo e($post->title); ?>" placeholder="Enter Title">

                        <input type="hidden" name="id" class="form-control" id="id" value="<?php echo e($post->id); ?>" placeholder="Enter Title">
                </div>
                <div class="form-group">
                    <label for="pwd">Post:</label>
                        <textarea name="post" id="" cols="60" rows="4" class="form-control" wrap="hard"> <?php echo e($post->post); ?></textarea>
                        
                </div>
        
            <button type="submit" class="btn btn-success">Update</button>
          </form>
                </div>
            </div>
        </div>
    </div>
</div>




<?php $__env->stopSection(); ?>


<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\xampp\htdocs\blogs\resources\views/edit_post.blade.php ENDPATH**/ ?>