

<?php $__env->startSection('content'); ?>
<div class="container">
    <div class="row justify-content-center">
        <div class="col-md-8">
            <div class="card">
                <div class="card-header"><?php echo e(__('View Post')); ?></div>

                <div class="card-body">
                    <?php if(session('status')): ?>
                        <div class="alert alert-success" role="alert">
                            <?php echo e(session('status')); ?>

                        </div>
                    <?php endif; ?>

                    

                   

                    <div class="p-2" style="text-align:right">

                        <a href="<?php echo e(route('home')); ?>" class="btn btn-primary "> View Post </a>
                       <!--  <button class="btn btn-primary "  type="button" data-toggle="modal" data-target="#myModal">Add Post</button> -->
                    </div>

             


                 <div >
                     <h3 class="p-2" > <?php echo e($post->title); ?></h3>
                                     
                    
                    <h4 class="p-3" >   <?php echo e($post->post); ?>  </h4>
                 </div>
                    
                    
                        
               </div>
               
            </div>
        </div>
    </div>
</div>




<?php $__env->stopSection(); ?>


<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\xampp\htdocs\blogs\resources\views/view_post.blade.php ENDPATH**/ ?>