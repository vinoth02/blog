<?php $__env->startSection('content'); ?>
<div class="container">
    <div class="row justify-content-center">
        <div class="col-md-8">
            <div class="card">
                <div class="card-header"><?php echo e(__('Dashboard')); ?></div>

                <div class="card-body">
                    <?php if(session('status')): ?>
                        <div class="alert alert-success" role="alert">
                            <?php echo e(session('status')); ?>

                        </div>
                    <?php endif; ?>

                    

                    <?php if(Auth::user()->role_id == 1): ?>

                    <div class="p-2" style="text-align:right">

                        <a href="<?php echo e(route('post.create')); ?>" class="btn btn-primary "> Add Post </a>
                       <!--  <button class="btn btn-primary "  type="button" data-toggle="modal" data-target="#myModal">Add Post</button> -->
                    </div>

                    <?php endif; ?>

                    <table class="table table-hover">
                        <thead>
                            <tr>
                                <th>S.no</th>
                                <th>Tiitle</th>
                                <th>Created</th>
                                <?php if(Auth::user()->role_id == 1): ?>
                                <th>Action</th>
                               <?php endif; ?>
                            </tr>
                        </thead>
                        <tbody>
                        <?php $i = 1; ?>
                        <?php $__currentLoopData = $post; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $post_list): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>

                            <tr>
                                <td> <?php echo e($i); ?> </td>
                                <td>
                                    <a href="<?php echo e(route('post.view', $post_list->id )); ?>" class="p-1"><?php echo e($post_list->title); ?>

                                    </a>
                                </td>
                                <td><?php echo e($post_list->created_at); ?></td>
                                <td> 
                                   
                                <?php if(Auth::user()->role_id == 1): ?>
                                
                                    <a href="<?php echo e(route('post.edit', $post_list->id )); ?>" class="p-1">Edit</a>
                                    <a href="<?php echo e(route('post.destroy', $post_list->id )); ?>" class="p-1">Delete</a>
                                
                                <?php endif; ?>
                                </td>
                            </tr>
                        <?php $i++; ?>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </tbody>

                        
                    </table>

                </div>
                <div class="p-2" align="right">
                    <?php echo e($post->links('pagination::bootstrap-4')); ?>

                </div>
                
            </div>
        </div>
    </div>
</div>

<!-- <div class="modal fade" id="myModal" role="dialog">
    <div class="modal-dialog">-->
    
      <!-- Modal content-->
    <!--  <div class="modal-content">
        <div class="modal-header">
        <h4 class="modal-title">Add Post</h4>
          <button type="button" class="close" data-dismiss="modal">&times;</button>
          
        </div>
        <div class="modal-body">
          <form action="<?php echo e(route('post.store')); ?>" method="post">
            <?php echo csrf_field(); ?>
          <div class="form-group">
            <label for="email">Title:</label>
                <input type="text" name="title" class="form-control" id="title" placeholder="Enter Title">
        </div>
        <div class="form-group">
            <label for="pwd">Post:</label>
                <textarea name="post" id="" cols="60" rows="4" class="form-control"></textarea>
                
        </div>
        
            <button type="submit" class="btn btn-success">Submit</button>
          </form>
        </div>
        <div class="modal-footer">
          <button type="button" class="btn btn-default" data-dismiss="modal">Close</button>
        </div>
      </div>
      
    </div>
  </div>

  <div class="modal fade" id="myModaledit" role="dialog">
    <div class="modal-dialog">-->
    
      <!-- Modal content-->
    <!--  <div class="modal-content">
        <div class="modal-header">
        <h4 class="modal-title">Update Post</h4>
          <button type="button" class="close" data-dismiss="modal">&times;</button>
          
        </div>
        <div class="modal-body">
          <form action="<?php echo e(route('post.update')); ?>" method="post">
            <?php echo csrf_field(); ?>
          <div class="form-group">
            <label for="email">Title:</label>
                <input type="text" name="title" class="form-control" id="title" id="post_title" placeholder="Enter Title">
        </div>
        <div class="form-group">
            <label for="pwd">Post:</label>
                <textarea name="post" id="" cols="60" rows="4" id="post_post" class="form-control"></textarea>
                
        </div>
        
            <button type="submit" class="btn btn-success">Update</button>
          </form>
        </div>
        <div class="modal-footer">
          <button type="button" class="btn btn-default" data-dismiss="modal">Close</button>
        </div>
      </div>
      
    </div>
  </div>


  <script type="text/javascript">
    
       function get_edit(data) {
            $.ajax({
                url : "<?php echo e(route('post.edit',"data")); ?>",
                type: "get",
                dataType:'json',
                success:function(data)
                {
                    $("#post_title").val('data.title');
                    $("#post_post").val('data.post');

                    console.log(data.title);
                }


            });

        }
</script> -->


<?php $__env->stopSection(); ?>


<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\xampp\htdocs\blogs\resources\views/home.blade.php ENDPATH**/ ?>